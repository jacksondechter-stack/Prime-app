import PrimeApp from '../components/PrimeApp';

export default function Home() {
  return <PrimeApp />;
}
